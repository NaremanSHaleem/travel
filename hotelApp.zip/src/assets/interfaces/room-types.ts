export interface RoomTypes {
}
