export interface Payment_info {
    card_holder: string,
    card_type: string,
    card_type_code: string,
    card_number: number,
    Expiration_date: string,
    CVC: number
}