import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TokenCheckService  {
  token =  null;
  Userdata;
  requiredLogin= false;
 
constructor() { }

}
