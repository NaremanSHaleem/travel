import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TokenCheckService } from 'src/assets/services/token-check.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'hotels-app';
  loginIsRequired ;
  constructor(  private router: Router,
    private route: ActivatedRoute,
    private tokenChecker: TokenCheckService){
    
  }
  get routerURL(){
    return this.router.url;
  }
  ngOnInit() {
  }
  ngOnChanges(){
    this.loginIsRequired =this.tokenChecker.requiredLogin;

  }
}
