import { Component, OnInit } from '@angular/core';
import { TokenCheckService } from 'src/assets/services/token-check.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor(private tokenChecher: TokenCheckService) { }

  ngOnInit() {
  }
  newsLetterSubmit(email) {
    if(this.tokenChecher.token == null){
      this.tokenChecher.requiredLogin = true;
      console.log('please login first');
    } else console.log(this.tokenChecher.token);
  }
}
