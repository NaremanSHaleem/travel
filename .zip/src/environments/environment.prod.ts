export const environment = {
  production: true,
  urlPath: "/hotels-app"
};
